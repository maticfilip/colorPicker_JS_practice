  const rectColor=document.querySelector(".rect");
  const resultElement = document.querySelector('.value');


const copyColor=elem=>{
  navigator.clipboard.writeText(resultElement.textContent);
  elem.innerText="Copied";
}

document.querySelectorAll(".color").forEach(li=>{
  li.addEventListener("click",e=>copyColor(e.currentTarget.lastElementChild));
});

document.getElementById('start-button').addEventListener('click', () => {

  
  if (!window.EyeDropper) {
    resultElement.textContent = 'Your browser does not support the EyeDropper API';
    return;
  }

  const eyeDropper = new EyeDropper();

  eyeDropper.open().then((result) => {
    resultElement.textContent = result.sRGBHex;
    rectColor.style.backgroundColor=result.sRGBHex;
  }).catch((e) => {
    resultElement.textContent = e;
  });
});

document.querySelector(".clear-all").addEventListener("click",()=>{
  const resultElement = document.querySelector('.value');
  const rectColor=document.querySelector(".rect");

  resultElement.textContent= "Undefined";
  rectColor.style.backgroundColor="#fff";
})